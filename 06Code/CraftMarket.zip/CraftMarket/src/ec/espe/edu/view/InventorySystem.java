package ec.edu.espe.inventorysystem.view;

import ec.edu.espe.inventorysystem.model.User;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Michael Chicaiza SOFTCRAF DCCO ESPE
 */
public class InventorySystem {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        ArrayList<User> users = new ArrayList<>();
        users.add(new User("alexis", "password123"));
        users.add(new User("maria", "hello123"));

        System.out.println("Enter your username: ");
        String enteredUsername = input.nextLine();
        System.out.println("Enter your password");
        String enteredPassword = input.nextLine();

        boolean loginSuccess = false;
        for (User user : users) {
            if (user.getUser().equals(enteredUsername) && user.verifyUser(enteredPassword)) {
                loginSuccess = true;
                break;
            }
        }
        if (loginSuccess) {
            System.out.println("Login successful");
        } else {
            System.out.println("Incorrect username or password");
        }
        input.close();
    }
}
