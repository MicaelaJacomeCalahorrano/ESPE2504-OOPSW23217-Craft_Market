
package ec.espe.edu.view;

import ec.espe.edu.model.Artisan;
import ec.espe.edu.model.Menu;
import ec.espe.edu.model.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Isaac Maisincho Crafters_Market DCCO ESPE
 */
public class CraftMarket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      /*   // TODO code application logic here
       // int id=001;
       // String name="Carlos";
       // String products="Aretes";
       // float totalFines=5;
       // Date date=new Date();
        String User = null;
        String Password = null;
        //Artisan artisan=new Artisan(id, name, products, totalFines, date);
        //System.out.println("Artisan Data -->" + artisan);
        Menu menu=new Menu(User, Password);*/
        ArrayList<User> users = new ArrayList<>();
        users.add(new User("alexis", "password123"));
        users.add(new User("maria", "hello123"));
        
        Scanner scanner = new Scanner(System.in);
        boolean loginSuccess = false;
        while (!loginSuccess) {
            System.out.println("==== INICIAR SESIÓN ====");
            System.out.print("User: ");
            String enteredUsername = scanner.nextLine();
            System.out.print("Password: ");
            String enteredPassword = scanner.nextLine();
            
            for (User user : users) {
                if (user.getUser().equals(enteredUsername) && user.verifyUser(enteredPassword)) {
                    loginSuccess = true;
                    break;
                }
            }
            if (loginSuccess) {
                System.out.println("Login successful");
                Menu.MostrarMenu();
            } else {
                System.out.println("Incorrect username or password. Try again.\n");
            }
        }
        scanner.close();
    }
    
    
}
