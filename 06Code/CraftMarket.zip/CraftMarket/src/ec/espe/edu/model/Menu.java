package ec.espe.edu.model;

import java.util.Scanner;

/**
 *
 * @author jorge
 */
public class Menu {
    String User;
    String Password;
    
    public Menu(String User, String Password) {
        String Password1 = this.Password;
        String User1 = this.User;
        menuInicial();

    
}
public static void menuInicial(){
    Scanner scanner = new Scanner(System.in);
    String User;
    String Password;
    System.out.println("==== INICIAR SESIÓN ====\n");
    System.out.println("User: ");
    User=scanner.nextLine();
    System.out.println("Password: ");
    Password = scanner.nextLine();
    
    MostrarMenu();
}
public static void MostrarMenu(){
        Scanner scanner = new Scanner(System.in);
        int option;
        int option2;
        System.out.println("==== Tienda de Artesanias ====\n");
        System.out.println("1.- Inventario \n");
        System.out.println("2.- Registro de ventas \n");
        System.out.println("3.- Asistencia\n");
        System.out.println("4.- Salir\n");
        System.out.println("==== Seleccione una opcion====\n");
        option = scanner.nextInt();
        if(option == 1){
            System.out.println("==== Inventario ====\n");
            System.out.println("0.- Volver\n");
            System.out.println("==== Seleccione una opcion====\n");
            option2 = scanner.nextInt();
            if(option2==0){
                MostrarMenu();
            }
        }else{
            if(option == 2){
                System.out.println("==== Registro de ventas ====\n");
                System.out.println("0.- Volver\n");
            System.out.println("==== Seleccione una opcion====\n");
            option2 = scanner.nextInt();
            if(option2==0){
                MostrarMenu();
            }
            }else{
                if(option == 3){
                  System.out.println("==== Asistencia ====\n");  
                  System.out.println("0.- Volver\n");
            System.out.println("==== Seleccione una opcion====\n");
            option2 = scanner.nextInt();
            if(option2==0){
                MostrarMenu();
            }
                }else{
                    if(option==4){
                        menuInicial();
                    }
                }
                
            }
            
        }
        

    }
}
